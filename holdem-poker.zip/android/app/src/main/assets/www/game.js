/* Hold'em: UI + game flow + bots. Depends on poker-core.js */
(() => {
'use strict';
const C = window.PokerCore;
const $ = (s, r = document) => r.querySelector(s);
const fmt = (n) => Math.round(n).toLocaleString('en-US');
const ABORT = { abort: true };

/* ---------- storage ---------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem('hld_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('hld_' + k, JSON.stringify(v)); } catch (e) {} },
  del(k) { try { localStorage.removeItem('hld_' + k); } catch (e) {} }
};
const DEFAULTS = { name: 'You', opponents: 4, chips: 5000, bb: 50, rise: false, difficulty: 'normal',
  speed: 'normal', sound: true, vibe: true, fourColor: false, hints: true };
let S = Object.assign({}, DEFAULTS, store.get('settings', {}));
const saveSettings = () => store.set('settings', S);
let stats = Object.assign({ hands: 0, won: 0, best: 0 }, store.get('stats', {}));

/* ---------- sound ---------- */
let ac = null;
function audio() {
  if (!S.sound) return null;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    if (ac.state === 'suspended') ac.resume();
  } catch (e) { return null; }
  return ac;
}
function tone(freq, dur, type, vol, delay) {
  const a = audio(); if (!a) return;
  const t = a.currentTime + (delay || 0);
  const o = a.createOscillator(), g = a.createGain();
  o.type = type || 'sine'; o.frequency.setValueAtTime(freq, t);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol || 0.07, t + 0.008);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + 0.02);
}
function noise(dur, freq, vol) {
  const a = audio(); if (!a) return;
  const n = Math.floor(a.sampleRate * dur), buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const src = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain();
  src.buffer = buf; f.type = 'bandpass'; f.frequency.value = freq; g.gain.value = vol;
  src.connect(f); f.connect(g); g.connect(a.destination); src.start();
}
const sfx = {
  deal: () => noise(0.06, 2600, 0.5),
  chip: () => { tone(1700, 0.05, 'triangle', 0.05); tone(2300, 0.05, 'triangle', 0.04, 0.045); },
  check: () => tone(180, 0.07, 'sine', 0.12),
  fold: () => noise(0.12, 900, 0.35),
  turn: () => { tone(660, 0.09, 'sine', 0.06); tone(880, 0.12, 'sine', 0.06, 0.08); },
  win: () => [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.22, 'triangle', 0.07, i * 0.09)),
  lose: () => { tone(330, 0.25, 'sine', 0.06); tone(247, 0.35, 'sine', 0.06, 0.15); }
};
const buzz = (ms) => { if (S.vibe && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) {} };

/* ---------- screens ---------- */
function show(id) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('on', s.id === id));
  if (id === 'menu') renderMenu();
}
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => show(b.dataset.go)));

let toastT;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, 1800);
}
function modal(html, wire) {
  const m = $('#modal'), sh = $('#sheet');
  sh.innerHTML = html; m.hidden = false;
  if (wire) wire(sh);
}
const closeModal = () => { $('#modal').hidden = true; };
const modalOpen = () => !$('#modal').hidden;

/* ---------- card rendering ---------- */
function cardHTML(c) {
  return '<i class="r">' + C.RANK_CH[c >> 2] + '</i><i class="s">' + C.SUITS[c & 3] + '</i>';
}
function makeCardEl(c) {
  const e = document.createElement('div');
  e.className = 'card s' + (c & 3); e.innerHTML = cardHTML(c); return e;
}
function setCard(el, c, up) {
  const key = c == null ? 'e' : up ? 'u' + c : 'b';
  if (el._k === key) return;
  const prev = el._k; el._k = key;
  el.classList.remove('up', 'back', 'empty', 's0', 's1', 's2', 's3', 'dim', 'hl');
  if (key === 'e') { el.classList.add('empty'); el.innerHTML = ''; return; }
  if (key === 'b') { el.classList.add('back'); el.innerHTML = ''; }
  else { el.classList.add('up', 's' + (c & 3)); el.innerHTML = cardHTML(c); }
  if (prev === undefined || prev === 'e' || key !== 'b') {
    el.classList.remove('deal'); void el.offsetWidth; el.classList.add('deal');
  }
}

/* ---------- menu ---------- */
function renderMenu() {
  const a = $('#markA'), b = $('#markB');
  a.className = 'mcard'; b.className = 'mcard';
  a.innerHTML = '<i class="r">A</i><i class="s">' + C.SUITS[0] + '</i>';
  b.innerHTML = '<i class="r">A</i><i class="s">' + C.SUITS[1] + '</i>';
  const saved = loadSave();
  $('#mContinue').hidden = !saved;
  $('#mStats').textContent = stats.hands
    ? stats.hands + ' hands played  ·  ' + stats.won + ' won  ·  best pot ' + fmt(stats.best) : '';
}
$('#mNew').onclick = () => { audio(); if (loadSave()) confirmNew(); else startGame(false); };
$('#mContinue').onclick = () => { audio(); startGame(true); };
$('#mHow').onclick = () => show('howto');
$('#mSettings').onclick = () => show('settings');
function confirmNew() {
  modal('<h2>Start a new game?</h2><p>Your saved game will be replaced.</p>' +
    '<button class="btn primary" id="cy">New game</button><button class="btn" id="cn">Cancel</button>', (sh) => {
    $('#cy', sh).onclick = () => { closeModal(); startGame(false); };
    $('#cn', sh).onclick = closeModal;
  });
}

/* ---------- settings ---------- */
const SCHEMA = [
  ['Game', [
    ['opponents', 'Opponents', 'How many computer players sit at your table.', [[1, '1'], [2, '2'], [3, '3'], [4, '4'], [5, '5']], true],
    ['chips', 'Starting chips', null, [[1000, '1,000'], [2500, '2,500'], [5000, '5,000'], [10000, '10,000']], true],
    ['bb', 'Blinds', 'Small / big blind. The forced bets that start each hand.', [[20, '10 / 20'], [50, '25 / 50'], [100, '50 / 100']], true],
    ['rise', 'Blinds rise', 'Doubles the blinds every 8 hands to keep the game moving.', [[false, 'Off'], [true, 'On']], true],
    ['difficulty', 'Opponent skill', null, [['easy', 'Easy'], ['normal', 'Normal'], ['hard', 'Hard']], false],
    ['speed', 'Game speed', null, [['slow', 'Relaxed'], ['normal', 'Normal'], ['fast', 'Fast']], false]
  ]],
  ['Help', [
    ['hints', 'Hand hints', 'Shows your current hand and rough win chance while you play.', [[true, 'On'], [false, 'Off']], false],
    ['fourColor', 'Four-colour cards', 'Each suit gets its own colour, which is easier to read.', [[false, 'Off'], [true, 'On']], false]
  ]],
  ['Feel', [
    ['sound', 'Sound', null, [[true, 'On'], [false, 'Off']], false],
    ['vibe', 'Vibration', 'A short buzz when it is your turn.', [[true, 'On'], [false, 'Off']], false]
  ]]
];
function renderSettings() {
  const body = $('#settingsBody'); body.innerHTML = '';
  const nameWrap = document.createElement('div');
  nameWrap.innerHTML = '<div class="group-t">Player</div><div class="group"><div class="set"><label for="nameIn">Your name</label>' +
    '<input id="nameIn" class="txt" maxlength="12" autocomplete="off" spellcheck="false"></div></div>';
  body.appendChild(nameWrap);
  const inp = $('#nameIn', nameWrap); inp.value = S.name === 'You' ? '' : S.name; inp.placeholder = 'You';
  inp.oninput = () => { S.name = inp.value.trim() || 'You'; saveSettings(); };
  let anyNew = false;
  SCHEMA.forEach(([title, items]) => {
    const t = document.createElement('div'); t.className = 'group-t'; t.textContent = title; body.appendChild(t);
    const g = document.createElement('div'); g.className = 'group'; body.appendChild(g);
    items.forEach(([key, label, desc, opts, newGame]) => {
      if (newGame) anyNew = true;
      const row = document.createElement('div'); row.className = 'set';
      row.innerHTML = '<span class="lab"></span>' + (desc ? '<div class="desc"></div>' : '') + '<div class="seg"></div>';
      $('.lab', row).textContent = label; if (desc) $('.desc', row).textContent = desc;
      const seg = $('.seg', row);
      opts.forEach(([val, text]) => {
        const b = document.createElement('button'); b.textContent = text;
        if (S[key] === val) b.className = 'on accent';
        b.onclick = () => {
          S[key] = val; saveSettings();
          seg.querySelectorAll('button').forEach((x) => { x.className = ''; }); b.className = 'on accent';
          if (key === 'sound' && val) sfx.chip();
          if (key === 'vibe' && val) buzz(30);
          applyTheme(); if (G.running) { render(); }
        };
        seg.appendChild(b);
      });
      g.appendChild(row);
    });
  });
  const n = document.createElement('p'); n.className = 'note';
  n.textContent = 'Opponents, chips and blinds apply when you start a new game. Everything else changes straight away.';
  body.appendChild(n);
  const g2 = document.createElement('div'); g2.className = 'group'; g2.style.marginTop = '16px';
  g2.innerHTML = '<div class="set"><span class="lab">Reset stats</span><div class="desc">Clears hands played, wins and best pot.</div>' +
    '<button class="btn wide danger" id="rs">Reset stats</button></div>';
  body.appendChild(g2);
  $('#rs', g2).onclick = () => { stats = { hands: 0, won: 0, best: 0 }; store.set('stats', stats); toast('Stats cleared'); };
}
function applyTheme() { document.body.classList.toggle('four', !!S.fourColor); }
$('#mSettings').addEventListener('click', renderSettings);

/* ---------- how to play ---------- */
const H = (s) => s.split(' ').map((x) => '23456789TJQKA'.indexOf(x[0]) * 4 + 'shdc'.indexOf(x[1]));
const RANKS = [
  ['Royal flush', 'A, K, Q, J, 10 of the same suit.', 'As Ks Qs Js Ts'],
  ['Straight flush', 'Five in a row, all the same suit.', '9h 8h 7h 6h 5h'],
  ['Four of a kind', 'Four cards of the same rank.', '8s 8h 8d 8c Kd'],
  ['Full house', 'Three of one rank and two of another.', 'Qs Qh Qd 4c 4s'],
  ['Flush', 'Any five cards of the same suit.', 'Ad Jd 8d 5d 3d'],
  ['Straight', 'Five in a row, any suits.', '9s 8h 7d 6c 5h'],
  ['Three of a kind', 'Three cards of the same rank.', '7s 7h 7d Kc 2h'],
  ['Two pair', 'Two different pairs.', 'Js Jh 4d 4c Ah'],
  ['Pair', 'Two cards of the same rank.', 'Ts Th Ad 6c 3h'],
  ['High card', 'None of the above. Your highest card plays.', 'As Jh 8d 5c 3h']
];
function renderHow() {
  const b = $('#howBody');
  b.innerHTML =
    '<h3>The goal</h3><p>Win chips by making the best five-card hand, or by getting everyone else to fold.</p>' +
    '<h3>Each hand</h3><ol class="steps">' +
    '<li><span><b>Blinds.</b> Two players put in forced bets so there is always something to win.</span></li>' +
    '<li><span><b>Your cards.</b> You get two private cards.</span></li>' +
    '<li><span><b>Betting round.</b> Each player folds, calls or raises.</span></li>' +
    '<li><span><b>The flop.</b> Three shared cards are turned over, then another betting round.</span></li>' +
    '<li><span><b>The turn and the river.</b> One more shared card each, with betting after both.</span></li>' +
    '<li><span><b>Showdown.</b> Your best five cards from your two plus the five shared ones. Best hand takes the pot.</span></li></ol>' +
    '<h3>Your choices</h3><ol class="steps">' +
    '<li><span><b>Fold.</b> Give up this hand. You lose what you already put in.</span></li>' +
    '<li><span><b>Check.</b> Pass, when nobody has bet.</span></li>' +
    '<li><span><b>Call.</b> Match the current bet.</span></li>' +
    '<li><span><b>Raise.</b> Make the bet bigger. Others must match it or fold.</span></li>' +
    '<li><span><b>All-in.</b> Bet every chip you have.</span></li></ol>' +
    '<h3>Hand rankings</h3><p>Best to worst. Tap <b>Hands</b> in a game to see this again.</p><div class="group" id="rankList"></div>';
  const list = $('#rankList', b);
  RANKS.forEach((r, i) => {
    const row = document.createElement('div'); row.className = 'rank';
    row.innerHTML = '<span class="n">' + (i + 1) + '</span><div class="t"><b></b><span></span></div><div class="mini"></div>';
    $('b', row).textContent = r[0]; $('span.n + .t span', row).textContent = r[1];
    const mini = $('.mini', row); H(r[2]).forEach((c) => mini.appendChild(makeCardEl(c)));
    list.appendChild(row);
  });
}
renderHow();
function showRanks() {
  modal('<h2>Hand rankings</h2><p>Best at the top.</p><div class="group" id="rl" style="margin-bottom:8px"></div><button class="btn" id="rc">Close</button>', (sh) => {
    const list = $('#rl', sh);
    RANKS.forEach((r, i) => {
      const row = document.createElement('div'); row.className = 'rank';
      row.innerHTML = '<span class="n">' + (i + 1) + '</span><div class="t"><b></b></div><div class="mini"></div>';
      $('b', row).textContent = r[0];
      const mini = $('.mini', row); H(r[2]).forEach((c) => mini.appendChild(makeCardEl(c)));
      list.appendChild(row);
    });
    $('#rc', sh).onclick = closeModal;
  });
}

/* ---------- game state ---------- */
const G = { running: false, sid: 0, players: [], dealer: -1, hand: 0, bb: 50, sb: 25, board: [], deck: [], turn: -1,
  pending: null, hl: null, cur: 0, minRaise: 50 };
const BOTS = ['Marcus', 'Priya', 'Tomas', 'Yuki', 'Rosa', 'Elias', 'Nadia'];
const LAYOUT = {
  2: [[50, 85], [50, 14]],
  3: [[50, 85], [22, 24], [78, 24]],
  4: [[50, 85], [13, 62], [50, 14], [87, 62]],
  5: [[50, 85], [13, 64], [20, 24], [80, 24], [87, 64]],
  6: [[50, 85], [13, 66], [13, 32], [50, 13], [87, 32], [87, 66]]
};
let seatEls = [], holeEls = [], betEls = [], boardEls = [];

const delay = () => ({ slow: 1500, normal: 900, fast: 350 }[S.speed]);
const sleep = (ms) => new Promise((res, rej) => {
  const sid = G.sid; setTimeout(() => (G.sid === sid ? res() : rej(ABORT)), ms);
});
const alive = (p) => !p.out && !p.folded;
const canAct = (p) => alive(p) && !p.allin;
const potTotal = () => G.players.reduce((s, p) => s + p.total, 0);

function loadSave() {
  const s = store.get('save', null);
  return s && s.players && s.players.length >= 2 && s.players[0].chips > 0 ? s : null;
}
function saveGame() {
  store.set('save', { players: G.players.map((p) => ({ name: p.name, chips: p.chips, aggr: p.aggr, bluff: p.bluff })),
    dealer: G.dealer, hand: G.hand, bb: G.bb });
}

function startGame(resume) {
  G.sid++;
  const sv = resume ? loadSave() : null;
  if (!resume) store.del('save');
  const n = sv ? sv.players.length : S.opponents + 1;
  G.bb = sv ? sv.bb : S.bb; G.sb = Math.floor(G.bb / 2);
  G.hand = sv ? sv.hand : 0; G.dealer = sv ? sv.dealer : -1;
  const names = C.shuffle(BOTS.slice());
  G.players = [];
  for (let i = 0; i < n; i++) {
    const src = sv ? sv.players[i] : null;
    G.players.push({
      i, human: i === 0, name: src ? src.name : i === 0 ? S.name : names[i - 1],
      chips: src ? src.chips : S.chips,
      aggr: src ? src.aggr : 0.8 + Math.random() * 0.5, bluff: src ? src.bluff : 0.03 + Math.random() * 0.08,
      hole: [], bet: 0, total: 0, folded: false, allin: false, out: false, tag: '', role: '', reveal: false, win: false
    });
  }
  if (sv) G.players[0].name = S.name;
  G.board = []; G.hl = null; G.turn = -1; G.pending = null;
  buildTable(); applyTheme(); show('game'); G.running = true;
  setMode('wait'); $('#status').textContent = ''; render();
  runGame();
}

function buildTable() {
  const seats = $('#seats'), bets = $('#bets'), board = $('#board');
  seats.innerHTML = ''; bets.innerHTML = ''; board.innerHTML = '';
  seatEls = []; holeEls = []; betEls = []; boardEls = [];
  const pos = LAYOUT[G.players.length];
  G.players.forEach((p, i) => {
    const [x, y] = pos[i];
    const el = document.createElement('div'); el.className = 'seat' + (p.human ? ' hero' : '');
    el.style.left = x + '%'; el.style.top = y + '%';
    el.innerHTML = '<div class="hole"><div class="card empty"></div><div class="card empty"></div></div>' +
      '<div class="plate"><div class="nm"><span></span><b class="role"></b></div><div class="ch"></div><div class="dealer" hidden>D</div></div><div class="tag"></div>';
    seats.appendChild(el); seatEls.push(el);
    holeEls.push([el.querySelectorAll('.hole .card')[0], el.querySelectorAll('.hole .card')[1]]);
    const be = document.createElement('div'); be.className = 'bet';
    be.style.left = (x + (50 - x) * 0.34) + '%'; be.style.top = (y + (46 - y) * 0.34) + '%';
    bets.appendChild(be); betEls.push(be);
  });
  for (let k = 0; k < 5; k++) { const c = document.createElement('div'); c.className = 'card empty'; board.appendChild(c); boardEls.push(c); }
}

function render() {
  if (!seatEls.length) return;
  const P = G.players;
  P.forEach((p, i) => {
    const el = seatEls[i];
    el.classList.toggle('fold', p.folded && !p.out);
    el.classList.toggle('out', p.out);
    el.classList.toggle('turn', G.turn === i);
    el.classList.toggle('win', !!p.win);
    $('.nm span', el).textContent = p.name;
    $('.role', el).textContent = p.role;
    $('.ch', el).textContent = p.out ? 'Out' : p.allin ? 'All-in' : p.chips <= 0 ? 'Busted' : fmt(p.chips);
    $('.dealer', el).hidden = G.dealer !== i || p.out;
    $('.tag', el).textContent = p.tag;
    for (let k = 0; k < 2; k++) {
      const ce = holeEls[i][k];
      setCard(ce, p.hole[k], p.human || p.reveal);
      const showHl = G.hl && p.win && p.hole[k] != null && (p.human || p.reveal);
      ce.classList.toggle('hl', !!(showHl && G.hl.has(p.hole[k])));
    }
    betEls[i].textContent = p.bet ? fmt(p.bet) : '';
  });
  for (let k = 0; k < 5; k++) {
    const ce = boardEls[k]; setCard(ce, G.board[k], true);
    const has = G.board[k] != null;
    ce.classList.toggle('dim', !!(G.hl && has && !G.hl.has(G.board[k])));
    ce.classList.toggle('hl', !!(G.hl && has && G.hl.has(G.board[k])));
  }
  const pot = potTotal();
  $('#pot').innerHTML = pot ? 'Pot <b>' + fmt(pot) + '</b>' : '';
  $('#gInfo').innerHTML = G.hand ? 'Hand <b>' + G.hand + '</b> &middot; Blinds <b>' + fmt(G.sb) + ' / ' + fmt(G.bb) + '</b>' : '';
}
function status(msg, big) { const s = $('#status'); s.textContent = msg; s.classList.toggle('big', !!big); }

/* ---------- action bar ---------- */
function setMode(m) {
  $('#btns').hidden = m === 'raise' || m === 'next';
  $('#raisePanel').hidden = m !== 'raise';
  $('#nextBtn').hidden = m !== 'next';
  const turn = m === 'turn';
  ['#aFold', '#aCall', '#aRaise'].forEach((s) => { $(s).disabled = !turn; });
}
function updateHint() {
  const h = $('#hint'), p = G.players[0];
  if (!S.hints || !p || !p.hole.length || p.out || p.folded) { h.innerHTML = p && p.folded && !p.out ? 'You folded this hand' : ''; return; }
  const cards = p.hole.concat(G.board);
  const nm = G.board.length >= 3 ? C.handName(C.evaluate(cards)) : C.preflopName(p.hole);
  const opp = G.players.filter((q) => q !== p && alive(q)).length;
  h.innerHTML = '<b>' + nm + '</b>';
  if (opp > 0 && !G.over) {
    const my = ++updateHint.n;
    setTimeout(() => {
      if (my !== updateHint.n) return;
      const e = C.equity(p.hole, G.board, opp, 300);
      h.innerHTML = '<b>' + nm + '</b> &middot; about ' + Math.round(e * 100) + '% to win';
    }, 30);
  }
}
updateHint.n = 0;

function askHuman(p) {
  return new Promise((resolve, reject) => {
    const toCall = Math.min(G.cur - p.bet, p.chips);
    const maxTo = p.chips + p.bet;
    const minTo = Math.min(maxTo, G.cur + G.minRaise);
    const canRaise = maxTo > G.cur;
    const callBtn = $('#aCall'), raiseBtn = $('#aRaise');
    callBtn.textContent = toCall === 0 ? 'Check' : toCall >= p.chips ? 'All-in ' + fmt(p.chips) : 'Call ' + fmt(toCall);
    raiseBtn.textContent = G.cur === 0 ? 'Bet' : 'Raise';
    raiseBtn.style.display = canRaise ? '' : 'none';
    G.pending = { resolve, reject };
    const done = (a) => { G.pending = null; setMode('wait'); resolve(a); };
    $('#aFold').onclick = () => done({ type: 'fold' });
    callBtn.onclick = () => done({ type: 'call' });
    raiseBtn.onclick = () => openRaise(p, minTo, maxTo, done);
    setMode('turn'); sfx.turn(); buzz(25);
    status(toCall === 0 ? 'Your turn. You can check or bet.' : 'Your turn. ' + fmt(toCall) + ' to call.');
  });
}
function openRaise(p, minTo, maxTo, done) {
  const sl = $('#rSlider'); let v = minTo;
  sl.min = minTo; sl.max = maxTo; sl.step = 1;
  const word = G.cur === 0 ? 'Bet' : 'Raise to';
  $('#rLabel').textContent = word;
  const upd = () => {
    v = Math.max(minTo, Math.min(maxTo, Math.round(v))); sl.value = v;
    $('#rAmt').textContent = fmt(v);
    $('#rConfirm').textContent = v >= maxTo ? 'All-in ' + fmt(v) : word + ' ' + fmt(v);
  };
  const pot = potTotal(), toCall = G.cur - p.bet;
  const sized = (f) => G.cur + f * (pot + toCall);
  const rnd = (x) => Math.round(x / G.sb) * G.sb;
  const q = $('#rQuick'); q.innerHTML = '';
  [['Min', minTo], ['½ Pot', rnd(sized(0.5))], ['Pot', rnd(sized(1))], ['All-in', maxTo]].forEach(([t, val]) => {
    const b = document.createElement('button'); b.className = 'q'; b.textContent = t;
    b.onclick = () => { v = val; upd(); sfx.chip(); }; q.appendChild(b);
  });
  sl.oninput = () => { v = +sl.value; upd(); };
  $('#rMinus').onclick = () => { v -= G.bb; upd(); };
  $('#rPlus').onclick = () => { v += G.bb; upd(); };
  $('#rCancel').onclick = () => setMode('turn');
  $('#rConfirm').onclick = () => done({ type: 'raise', to: v });
  upd(); setMode('raise');
}

/* ---------- bots ---------- */
function botDecide(p) {
  const toCall = G.cur - p.bet, pot = potTotal();
  const opp = G.players.filter((q) => q !== p && alive(q)).length;
  const sims = { easy: 70, normal: 150, hard: 280 }[S.difficulty];
  let eq = C.equity(p.hole, G.board, opp, sims);
  if (S.difficulty === 'easy') eq += (Math.random() - 0.5) * 0.26;
  if (S.difficulty === 'hard' && toCall > G.bb * 3) eq -= 0.03;
  const maxTo = p.chips + p.bet, minTo = Math.min(maxTo, G.cur + G.minRaise);
  const canRaise = maxTo > G.cur;
  const r = Math.random();
  const size = (frac) => {
    let to = G.cur + Math.max(G.minRaise, frac * (pot + toCall));
    to = Math.round(to / G.sb) * G.sb;
    return Math.max(minTo, Math.min(maxTo, to));
  };
  const bluff = p.bluff * (G.board.length >= 3 ? 1 : 0.5);
  if (toCall <= 0) {
    if (canRaise && eq > 0.66 && r < 0.78) return { type: 'raise', to: size(0.5 + Math.random() * 0.4) };
    if (canRaise && eq > 0.52 && r < 0.32 * p.aggr) return { type: 'raise', to: size(0.33 + Math.random() * 0.15) };
    if (canRaise && r < bluff) return { type: 'raise', to: size(0.5) };
    return { type: 'call' };
  }
  const odds = toCall / (pot + toCall);
  const need = odds + 0.05;
  if (canRaise && eq > 0.76 && r < 0.6 * p.aggr) return { type: 'raise', to: size(0.7 + Math.random() * 0.4) };
  if (canRaise && eq > 0.63 && r < 0.2 * p.aggr) return { type: 'raise', to: size(0.6) };
  if (toCall <= G.bb && eq > need - 0.1) return { type: 'call' };
  if (eq >= need) return { type: 'call' };
  if (canRaise && toCall <= pot * 0.5 && r < bluff * 0.5) return { type: 'raise', to: size(0.8) };
  return { type: 'fold' };
}

/* ---------- hand flow ---------- */
const next = (i, pred) => {
  const n = G.players.length;
  for (let k = 1; k <= n; k++) { const j = (i + k) % n; if (pred(G.players[j])) return j; }
  return i;
};
function post(p, amt) {
  const a = Math.min(amt, p.chips); p.chips -= a; p.bet += a; p.total += a;
  if (p.chips === 0) { p.allin = true; p.tag = 'All-in'; }
}
function applyAction(p, a) {
  if (a.type === 'fold') { p.folded = true; p.tag = 'Fold'; sfx.fold(); return false; }
  if (a.type === 'call') {
    const amt = Math.min(G.cur - p.bet, p.chips);
    post(p, amt);
    if (!p.allin) p.tag = amt === 0 ? 'Check' : 'Call'; amt === 0 ? sfx.check() : sfx.chip();
    return false;
  }
  const to = Math.max(G.cur + 1 > p.chips + p.bet ? p.chips + p.bet : G.cur + 1, Math.min(a.to, p.chips + p.bet));
  const raiseBy = to - G.cur;
  post(p, to - p.bet);
  if (raiseBy >= G.minRaise) G.minRaise = raiseBy;
  const opening = G.cur === 0;
  G.cur = to;
  if (!p.allin) p.tag = opening ? 'Bet' : 'Raise';
  sfx.chip();
  return true;
}
async function betRound(first) {
  const P = G.players;
  G.cur = Math.max(0, ...P.map((p) => p.bet));
  const pending = new Set(P.filter(canAct).map((p) => p.i));
  let i = first;
  let guard = 0;
  while (pending.size && guard++ < 500) {
    if (P.filter(alive).length <= 1) break;
    const p = P[i];
    if (pending.has(i)) {
      if (!canAct(p)) pending.delete(i);
      else {
        const others = P.filter((q) => q !== p && canAct(q)).length;
        if (p.bet >= G.cur && others === 0) { pending.delete(i); i = (i + 1) % P.length; continue; }
        G.turn = i; render();
        let a;
        if (p.human) { updateHint(); a = await askHuman(p); }
        else { await sleep(delay() * (0.6 + Math.random() * 0.8)); a = botDecide(p); }
        G.turn = -1;
        const raised = applyAction(p, a);
        pending.delete(i);
        if (raised) P.forEach((q) => { if (q !== p && canAct(q)) pending.add(q.i); });
        render(); status('');
        if (!p.human) await sleep(Math.min(300, delay() * 0.35));
      }
    }
    i = (i + 1) % P.length;
  }
  P.forEach((p) => { p.bet = 0; if (p.tag !== 'Fold' && p.tag !== 'All-in') p.tag = ''; });
  G.cur = 0; G.minRaise = G.bb; render();
}

async function playHand() {
  const P = G.players;
  P.forEach((p) => {
    p.out = p.chips <= 0; p.hole = []; p.bet = 0; p.total = 0; p.folded = p.out; p.allin = false;
    p.tag = ''; p.role = ''; p.reveal = false; p.win = false;
  });
  G.hand++; G.over = false;
  if (S.rise && G.hand > 1 && (G.hand - 1) % 8 === 0) {
    G.bb *= 2; G.sb = Math.floor(G.bb / 2); toast('Blinds up: ' + fmt(G.sb) + ' / ' + fmt(G.bb));
  }
  G.board = []; G.hl = null; G.minRaise = G.bb; G.cur = 0;
  G.dealer = next(G.dealer < 0 ? P.length - 1 : G.dealer, (p) => !p.out);
  const inPlay = P.filter((p) => !p.out);
  const headsUp = inPlay.length === 2;
  const sbI = headsUp ? G.dealer : next(G.dealer, (p) => !p.out);
  const bbI = next(sbI, (p) => !p.out);
  P[sbI].role = 'SB'; P[bbI].role = 'BB';
  post(P[sbI], G.sb); post(P[bbI], G.bb);
  G.deck = C.shuffle(C.makeDeck());
  setMode('wait'); status('Dealing...'); render(); updateHint();
  await sleep(250);
  for (let r = 0; r < 2; r++) {
    for (let k = 1; k <= P.length; k++) {
      const p = P[(G.dealer + k) % P.length];
      if (p.out) continue;
      p.hole.push(G.deck.pop()); sfx.deal(); render(); await sleep(70);
    }
  }
  status(''); updateHint();
  await sleep(200);

  const streets = [['Flop', 3], ['Turn', 1], ['River', 1]];
  let first = headsUp ? G.dealer : next(bbI, (p) => !p.out);
  // advance to a player that can act
  const firstActor = (from) => { let j = from; for (let k = 0; k < P.length; k++) { if (canAct(P[j])) return j; j = (j + 1) % P.length; } return from; };
  await betRound(firstActor(first));
  for (let s = 0; s < 3 && P.filter(alive).length > 1; s++) {
    if (P.filter(canAct).length <= 1) {
      // nobody can bet any more: show cards and run the board out
      if (!P.some((p) => p.reveal)) { P.forEach((p) => { if (alive(p)) p.reveal = true; }); render(); status('All-in. Cards up.'); await sleep(delay()); }
    }
    for (let k = 0; k < streets[s][1]; k++) { G.board.push(G.deck.pop()); sfx.deal(); render(); await sleep(150); }
    updateHint();
    if (P.filter(canAct).length > 1) {
      status(streets[s][0]);
      await betRound(firstActor(next(G.dealer, () => true)));
    } else { await sleep(delay()); }
  }
  await showdown();
}

function resolve(showdown) {
  const P = G.players;
  if (showdown) P.forEach((p) => { if (alive(p)) p.score = C.evaluate(p.hole.concat(G.board)); });
  const levels = [...new Set(P.filter((p) => p.total > 0).map((p) => p.total))].sort((a, b) => a - b);
  let prev = 0, carry = 0; const won = new Map(); const lines = []; let firstHand = null;
  levels.forEach((lvl, li) => {
    let amt = carry; carry = 0;
    P.forEach((p) => { amt += Math.max(0, Math.min(p.total, lvl) - Math.min(p.total, prev)); });
    prev = lvl;
    const elig = P.filter((p) => alive(p) && p.total >= lvl);
    if (!elig.length) { carry = amt; return; }
    let winners = elig;
    if (showdown) { const best = Math.max(...elig.map((p) => p.score)); winners = elig.filter((p) => p.score === best); }
    const share = Math.floor(amt / winners.length); let rem = amt - share * winners.length;
    winners.forEach((p) => { const g = share + (rem > 0 ? 1 : 0); rem = Math.max(0, rem - 1); won.set(p, (won.get(p) || 0) + g); });
    if (!firstHand) firstHand = winners;
  });
  return { won, firstHand };
}

async function showdown() {
  const P = G.players, pot = potTotal();
  const contenders = P.filter(alive);
  const sd = contenders.length > 1;
  G.over = true;
  if (sd) { P.forEach((p) => { if (alive(p)) p.reveal = true; }); }
  const { won, firstHand } = resolve(sd);
  won.forEach((amt, p) => { p.chips += amt; p.win = true; });
  P.forEach((p) => { p.allin = false; });
  const names = [];
  const lines = [];
  won.forEach((amt, p) => {
    const nm = p.human ? 'You' : p.name;
    lines.push(nm + (p.human ? ' win ' : ' wins ') + fmt(amt) + (sd ? ' with ' + C.handName(p.score).replace(/^./, (c) => c.toLowerCase()) : ''));
  });
  if (sd && firstHand && firstHand.length) {
    const w = firstHand[0];
    G.hl = new Set(C.bestFive(w.hole.concat(G.board)));
  }
  const heroWon = won.has(P[0]);
  stats.hands++; if (heroWon) { stats.won++; stats.best = Math.max(stats.best, won.get(P[0])); }
  store.set('stats', stats);
  P.forEach((p) => { p.bet = 0; p.tag = ''; });
  G.turn = -1; render();
  status(sd ? lines.join('\n') : lines.join('\n') + ' (everyone else folded)', true);
  updateHint();
  if (heroWon) { sfx.win(); buzz([40, 60, 40]); } else if (P[0].folded || P[0].chips === 0) sfx.lose();
}

async function runGame() {
  const sid = G.sid;
  try {
    for (;;) {
      await playHand();
      saveGame();
      const P = G.players, hero = P[0];
      const botsLeft = P.slice(1).some((p) => p.chips > 0);
      const last = hero.chips <= 0 || !botsLeft;
      await waitNext(last ? 'Continue' : 'Next hand');
      if (last) { endGame(hero.chips > 0); return; }
    }
  } catch (e) { if (e !== ABORT) console.error(e); }
  if (G.sid === sid) G.running = false;
}
function waitNext(label) {
  return new Promise((resolve, reject) => {
    const b = $('#nextBtn'); b.textContent = label; setMode('next');
    G.pending = { resolve, reject };
    b.onclick = () => { G.pending = null; setMode('wait'); resolve(); };
  });
}
function endGame(won) {
  store.del('save'); G.running = false;
  const hands = G.hand;
  modal(won
    ? '<h2>You cleaned out the table</h2><p>Every opponent is out of chips after ' + hands + ' hands. Well played.</p>'
    : '<h2>You are out of chips</h2><p>Your run ended after ' + hands + ' hands.</p>',
  (sh) => {
    const a = document.createElement('button'); a.className = 'btn primary'; a.textContent = 'Play again';
    const b = document.createElement('button'); b.className = 'btn'; b.textContent = 'Main menu';
    sh.appendChild(a); sh.appendChild(b);
    a.onclick = () => { closeModal(); startGame(false); };
    b.onclick = () => { closeModal(); show('menu'); };
  });
}

/* ---------- pause / back ---------- */
function abortGame() {
  G.sid++; G.running = false;
  if (G.pending) { const p = G.pending; G.pending = null; try { p.reject(ABORT); } catch (e) {} }
}
function pauseMenu() {
  const SPEED = ['slow', 'normal', 'fast'], SL = { slow: 'Relaxed', normal: 'Normal', fast: 'Fast' };
  modal('<h2>Paused</h2><p>Your game is saved after every hand.</p>' +
    '<button class="btn primary" id="pr">Resume</button>' +
    '<button class="btn" id="psn"></button><button class="btn" id="psp"></button>' +
    '<button class="btn" id="pq">Quit to menu</button>', (sh) => {
    const lab = () => {
      $('#psn', sh).textContent = 'Sound: ' + (S.sound ? 'On' : 'Off');
      $('#psp', sh).textContent = 'Speed: ' + SL[S.speed];
    };
    lab();
    $('#pr', sh).onclick = closeModal;
    $('#psn', sh).onclick = () => { S.sound = !S.sound; saveSettings(); lab(); if (S.sound) sfx.chip(); };
    $('#psp', sh).onclick = () => { S.speed = SPEED[(SPEED.indexOf(S.speed) + 1) % 3]; saveSettings(); lab(); };
    $('#pq', sh).onclick = () => { closeModal(); abortGame(); show('menu'); };
  });
}
$('#gMenu').onclick = pauseMenu;
$('#gHelp').onclick = showRanks;
$('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') closeModal(); });
window.__back = () => {
  if (modalOpen()) { closeModal(); return true; }
  const on = document.querySelector('.screen.on').id;
  if (on === 'game') { pauseMenu(); return true; }
  if (on !== 'menu') { show('menu'); return true; }
  return false;
};
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') window.__back(); });
document.addEventListener('pointerdown', () => { if (S.sound) audio(); }, { once: true });

/* ---------- boot ---------- */
applyTheme(); renderMenu();
if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(() => {});
window.__hld = { G, S, startGame }; // handy for testing
})();
