# Hold'em - offline Texas Hold'em

`www/` is the whole game (plain HTML/CSS/JS, no internet needed). Open `www/index.html` in a browser to play.

## Get the APK
Option A, no installs: push the `android/` folder to a new GitHub repo. The "Build APK" action runs and
leaves `holdem-apk` under Actions > latest run > Artifacts. Unzip, send `app-debug.apk` to your phone, install it
(allow "install unknown apps" when asked).

Option B, Android Studio: File > Open > `android/`, then Build > Build APK(s).
Or in a terminal with the Android SDK set up: `cd android && ./gradlew assembleDebug`
(APK appears in `app/build/outputs/apk/debug/`).

If you edit `www/`, copy it over `android/app/src/main/assets/www/` (delete `sw.js` there) before building.
